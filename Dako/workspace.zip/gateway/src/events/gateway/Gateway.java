package events.gateway;
import events.main.Application;


public class Gateway {
	public static void main(String[] args) throws Exception {
		Application app = new Application();
		app.run();
	}
}
