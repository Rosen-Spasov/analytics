package events.gui;
import events.main.Application;


public class GUI {
	public static void main(String[] args) throws Exception {
		Application app = new Application();
		app.run();
	}
}
