import events.main.Application;


public class Reader {
	
	public static void main(String[] args) throws Exception {
		Application app = new Application();
		app.run();
	}
}
