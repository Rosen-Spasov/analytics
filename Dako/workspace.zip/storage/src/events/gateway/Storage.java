package events.gateway;
import events.main.Application;


public class Storage {
	public static void main(String[] args) throws Exception {
		Application app = new Application();
		app.run();
	}
}
